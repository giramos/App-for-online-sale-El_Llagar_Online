package uo.main;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import uo.impl.Manzana;
import uo.impl.Reader;
import uo.impl.Writer;
/**
 * 
 * @author Germ�n Iglesias Ramos UO202549
 *
 */
public class Aplicacion {

	public static void main(String[] args) {
		execute(args[0]);
	}

	private static void execute(String xml) {
		try {
			Reader reader = new Reader(xml);
			Writer writer = new Writer();
			ArrayList<Manzana> manzanas = reader.getManzanas();
			
			System.out.println("Manzanas �cidas, amargas y dulces disponibles, seg�n la zona geogr�fica "
					+ "en Asturias: ");
			System.out.println();
			System.out.println("Norte");
			System.out.println("Sur");
			System.out.println("Este");
			System.out.println("Oeste");

			System.out.print("\n");
			System.out.println("\nIntroduzca un tipo (Norte, Sur, Este u Oeste): "
					+ " --> Distingue entre MAY/MIN, por favor sea expl�cito al introducir el tipo ");
			
			while (true) {
				BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
				String tipo = entrada.readLine();
				ArrayList<Manzana> seleccion = getManzanasByTipo(tipo, manzanas);
				if (seleccion.size() > 0) {
					writer.exportarXML(seleccion, tipo);
					System.out.println("XML generado con gran �x�to");
					break;
				}
				System.out.println("No existen manzanas de este tipo, reintroduzca un tipo de zona de manzana, por favor ");
			}

		} catch (Exception e) {
			System.out.println("Ha ocurrido alg�n error");
		}
	}

	public static ArrayList<Manzana> getManzanasByTipo(String tipo, ArrayList<Manzana> manzanas) {
		String[] s = tipo.split("");
		String cad = "";
		for (int j = 0; j < s.length - 1; j++) {
			cad += s[j].toString();
		}
		tipo = cad;
		ArrayList<Manzana> manzanaTipo = new ArrayList<Manzana>();
		for (int i = 0; i < manzanas.size(); i++) {
			if (manzanas.get(i).getTipo().equals(tipo)) {
				manzanaTipo.add(manzanas.get(i));
			}
		}
		return manzanaTipo;
	}
}
