package uo.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public class Reader {

	private ArrayList<Manzana> manzanas = new ArrayList<Manzana>();
	private String xml = null;

	public Reader(String xml) {
		this.xml = xml;
		cargarXml();
	}
	
	public ArrayList<Manzana> getManzanas() {
		return manzanas;
	}

	@SuppressWarnings("rawtypes")
	private void cargarXml() {
		SAXBuilder builder = new SAXBuilder();
		File xmlFile = new File(xml);
		try {
			Document document = (Document) builder.build(xmlFile);
			Element rootNode = document.getRootElement();
			List list = rootNode.getChildren("manzana");

			for (int i = 0; i < list.size(); i++) {
				Element tabla = (Element) list.get(i);
				
				List lista_campos = tabla.getChildren();
				String nombre = null;
				int temporada = 0;
				int posicion = 0;
				int nivel = 0;
				for (int j = 1; j <= 5; j++) {
					Element campo = (Element) lista_campos.get(j);
					if (j == 1) {
						nombre = campo.getText();
					} else if (j == 3) {
						temporada = Integer.valueOf(campo.getValue());
					} else if (j == 4) {
						posicion = Integer.valueOf(campo.getValue());
					} else if (j == 5) {
						nivel = Integer.valueOf(campo.getValue());
					}

				}

				manzanas.add(new Manzana(nombre, temporada, posicion, nivel));

			}
		} catch (IOException io) {
			System.out.println(io.getMessage());
		} catch (JDOMException jdomex) {
			System.out.println(jdomex.getMessage());
		}
	}

	

}
