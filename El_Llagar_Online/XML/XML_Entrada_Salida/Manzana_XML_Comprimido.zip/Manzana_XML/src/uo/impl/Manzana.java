package uo.impl;

public class Manzana {

	private String nombre;
	private int temporada;
	private int posicion;
	private int nivel;
	private String tipo;

	public Manzana(String name, int temp, int pos, int niv) {
		this.nombre = name;
		this.temporada = temp;
		this.posicion = pos;
		this.nivel = niv;
		clasifica();
	}

	private void clasifica() {
		if (posicion == 1) {
			tipo = "Nort";
		} else if (posicion == 2) {
			tipo = "Su";
		} else if (posicion == 3) {
			tipo = "Est";
		} else if (posicion == 4) {
			tipo = "Oest";
		}
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	

	public void setTemporada(int temporada) {
		this.temporada = temporada;
	}

	public int getPosicion() {
		return posicion;
	}

	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String toString() {
		return nombre + "\t" + temporada + "\t" + posicion + "\t" + nivel;
	}

	public int getTemporada() {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		return temporada;
	}
}
