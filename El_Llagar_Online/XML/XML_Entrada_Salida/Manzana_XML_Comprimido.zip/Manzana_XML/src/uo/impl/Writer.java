package uo.impl;
import java.io.FileWriter;
import java.util.ArrayList;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class Writer {
	
	public void exportarXML(ArrayList<Manzana> manzanas,String tipo){
	    try {
		Element manzana = new Element("manzanas");
	    Document documento = new Document(manzana);
	    
	    for(Manzana p:manzanas) {
	    	Element play = new Element("manzana");
	    	play.addContent(new Element("nombre").setText(p.getNombre()));
	    	play.addContent(new Element("posicion_geografica").setText(String.valueOf(p.getPosicion())));
	    	play.addContent(new Element("mes_temporada").setText(String.valueOf(p.getTemporada())));
	    	play.addContent(new Element("nivel").setText(String.valueOf(p.getNivel())));
	    	documento.getRootElement().addContent(play);
	    }
	    XMLOutputter output = new XMLOutputter();
	    output.setFormat(Format.getPrettyFormat());
	    output.output(documento, new FileWriter("manzanas-tipo-"+tipo+".xml"));
	    }catch(Exception e) {
	    	System.out.println("Ha acurrido alg�n error");
	    }
	}

}
